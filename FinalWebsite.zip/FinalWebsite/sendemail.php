﻿<?php

if(isset($_POST['submit'])){
    //$to = "sheenad18@gmail.com"; // this is your Email address
    //$from = $_POST['emailaddress']; // this is the sender's Email address
    //$name = "Name" . $_POST['name'];
    //$event = "Type of Event" . $_POST['event'];
    //$date = $_POST['date'];
    //$subject = "New Booking Request";
    //$details = "Additional Details:" . "\n\n" . $_POST['details'];
   // $headers = "From:" . $from;
    //mail($to,$subject,$details,$headers);
    //echo "Thank you " . $name . "! Your request has been received. You will be contacted you shortly.";
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    echo "Got your info, thanks!";
}
?>
